package Classes;

public interface Hospital {

    String getHospitalName();

    void setHospitalName(String universityName);

    String getHospitalAddress();

    void setHospitalAddress(String UniversityAddress);
}
